#!/bin/bash
. prereq_aocc_configure.sh
. prereq_aocc_env_setup.sh

# Build prerequisites
. jemalloc_build.sh
. openmpi_aocc_build.sh
. hdf5_aocc_build.sh
. pnetcdf_aocc_build.sh 
. netcdf_aocc_build.sh

# Generate set environment file
. prereq_aocc_setenv.sh
