#!/bin/bash
. prereq_icc_configure.sh
. prereq_icc_env_setup.sh

# Build prerequisites
. jemalloc_build.sh
. openmpi_icc_build.sh
. hdf5_icc_build.sh
. pnetcdf_icc_build.sh 
. netcdf_icc_build.sh

# Generate set environment file
. prereq_icc_setenv.sh
